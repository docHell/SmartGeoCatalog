export class ElasticExport {
    _id: string;   
    rndt_json: object;
     
    constructor(id: string) {
        this._id =id;
    }



  }
  