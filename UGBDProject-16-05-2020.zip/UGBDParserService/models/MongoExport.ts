export class MongoExport {
    _id: string;   
    rndt_json: object;
    rndt_xml : string;

    constructor(id: string) {
        this._id =id;
    }



  }
  