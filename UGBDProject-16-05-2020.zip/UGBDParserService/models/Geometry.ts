export class location {
    type : string;
    coordinates : any [];

    constructor ( type: string, coordinates : any) {
        this.type = type;
        this.coordinates = coordinates;
    }
}


 