import { EventRemote } from './../providers/EventRemote';
import { RemoteStatus } from './../providers/RemoteStatus';
import { QueryRemote } from './../providers/QueryRemote';
import app from "./app";
import { Risposta } from '../models/Risposta';
import { ParserRemote } from '../providers/ParserRemote';
import { ElasticRemote } from '../providers/ElasticRemote';
import { MongoRemote } from '../providers/MongoRemote';
import { connect } from 'mqtt';
import CONFIG from '../config/config.json';


const TOPIC = "update_csw";
const ELASTIC_TOPIC = "store_elastic";
const CONTACTS_TOPIC = "update_contacts";
const ANSWER_TOPIC = "answer_topic"

console.log(RemoteStatus.getInstace().updateStatus(new Risposta("QueryService", false, null)));
console.log(RemoteStatus.getInstace().getStatus());


// const client = connect(CONFIG.mqtt, { clean: false, clientId: CONFIG.name, keepalive: 5 });
// client.subscribe(CONFIG.STATUS_TOPIC)
EventRemote.getInstace().client.subscribe(CONFIG.STATUS_TOPIC)


app.post(
  "/toParse/", (req, res, next) => {
    ParserRemote.getInstance().toparse(req.body).then((ris: Risposta) => {
      console.log("Parsing method has been called")
      res.json(ris);
    }).catch((err) => {
      EventRemote.getInstace().sendError("/toParse "+ JSON.stringify(err));
      res.json(new Risposta("Errore query Edge", false, err));
    });
  });

app.post(
  "/upload/", (req, res, next) => {
    ParserRemote.getInstance().toparse(req.body).then((ris: Risposta) => {
      console.log("Upload method has been called")
      if (ris.esito) {

        ElasticRemote.getInstance().addNewMetadata(ris.valore.elasticExport).then((ris2: Risposta) => {

          if (ris2.esito) {
            EventRemote.getInstace().client.publish(TOPIC, JSON.stringify(ris.valore.mongoExport));
            EventRemote.getInstace().client.publish(CONTACTS_TOPIC, JSON.stringify(ris.valore.contacts));
          } else {
            EventRemote.getInstace().sendWarning(JSON.stringify([ris,ris2]),ris2.esito);
            console.log("->" + JSON.stringify(ris2));
          }
          res.json(ris2);
        }).catch((err) => {
          console.log("ERROR :  " + err);
          EventRemote.getInstace().sendError("/upload "+ JSON.stringify(err));
          res.json(new Risposta("Errore uploading", false, err));
          console.log("-----------------------------------------------------------------");
        });

      } else {
        EventRemote.getInstace().sendWarning(JSON.stringify(ris),ris.esito);
        res.json(new Risposta("Errore parsing ", false, ris.valore));
      }

    }).catch((err) => {
      EventRemote.getInstace().sendError("/upload "+ JSON.stringify(err));
      res.json(new Risposta("Errore parsing 2", false, err));
    });
  });



app.post(
  "/saveMetadata/", (req, res, next) => {


    ElasticRemote.getInstance().addNewMetadata(req.body.elasticExport).then((ris: Risposta) => {

      if (ris.esito) {
        // console.log("-> OK");
        EventRemote.getInstace().client.publish(TOPIC, JSON.stringify(req.body.mongoExport));
        EventRemote.getInstace().client.publish(CONTACTS_TOPIC, JSON.stringify(req.body.contacts));
      } else {
        EventRemote.getInstace().sendWarning(JSON.stringify(ris),ris.esito);
        console.log("->" + JSON.stringify(ris));
      }

    }).catch((err) => {
      EventRemote.getInstace().sendError("/saveMetadata "+ JSON.stringify(err));
      res.json(new Risposta("Errore query Edge", false, err));
      console.log("-----------------------------------------------------------------");
    });
  });

app.get("/getAllContacts", (req, res) => {
  MongoRemote.getInstance()
    .getAllContacts()
    .then((risposta: Risposta) => {
      console.log("--------------------------------------");
      console.log(JSON.stringify(risposta));
      console.log("--------------------------------------");
      res.json(risposta);
    }).catch((err) => {
      EventRemote.getInstace().sendError("Errore 2 /getAllContacts "+ JSON.stringify(err));
      res.json(new Risposta("Errore 2 /getAllContacts", false, err));
    })

});

app.get("/countAll", async (req, res) => {
  await MongoRemote.getInstance()
    .countAll()
    .then((risposta: Risposta) => {
      console.log("--------------------------------------");
      console.log(JSON.stringify(risposta));
      console.log("--------------------------------------");
      res.json(risposta);
    }).catch((err) => {
      EventRemote.getInstace().sendError("Errore 2 /countAll " + JSON.stringify(err));
      res.json(new Risposta("Errore 2 /countAll", false, err));
    })

});

app.get("/test", async (req, res) => {

  res.json(RemoteStatus.getInstace().getStatus());

});


//---------------------------QUERY 

app.get(
  "/getAll_E", (req, res, next) => {
    console.log("--- GET ALL UGBD METADATA REQUEST USING ELASTIC---");
    QueryRemote.getInstance()
      .getAll()
      .then((risposta: Risposta) => {
        res.json(risposta);
      }).catch((err) => {
        EventRemote.getInstace().sendError("Errore 3 getAll_E" + JSON.stringify(err));
        res.json(new Risposta("Errore 3 getAll_E", false, err));
      });
  }
);


app.post(
  "/getQuery_Response", (req, res, next) => {
    console.log("--- GET ALL UGBD METADATA REQUEST USING ELASTIC GEO CAPABILITIES---");
    console.log("-------------------------------------------------------------------")
    console.log(req.body);
    console.log("-------------------------------------------------------------------")
    QueryRemote.getInstance()
      .getQueryResponse(req.body)
      .then((risposta: Risposta) => {
        console.log("--------------------------------------");
        console.log(risposta);
        console.log("--------------------------------------");
        res.json(risposta);
      }).catch( (err) => {
        EventRemote.getInstace().sendError("Error2 getQuery_Response" + JSON.stringify(err));
        res.json(new Risposta("Error2 getQuery_Response", false, null));
      })
  }
);

app.get(
  "/getByID/:metadataId", (req, res, next) => {
    console.log("getProductByID----------------------------");
    console.log("req.params.metadataId ->", req.params.metadataId);
    MongoRemote.getInstance()
      .findMetadataByID(req.params.metadataId)
      .then((risposta: Risposta) => {
        res.json(risposta);
      }).catch(() => {
        EventRemote.getInstace().sendError("Error2 getAll: "+  req.params.metadataId);
        res.json(new Risposta("Error2 getByID", false, null));
      });
  }
);

app.get(
  "/DownloadMetadata/:metadataId", (req, res, next) => {
    console.log("getProductByID----------------------------");
    console.log("req.params.metadataId ->", req.params.metadataId);
    MongoRemote.getInstance()
      .findMetadataByID(req.params.metadataId)
      .then((risposta: Risposta) => {
        res.set({ "Content-Disposition": "attachment; filename=metadata.xml " });
        res.send(risposta.valore.rndt_xml);
      }).catch((err) => {
        EventRemote.getInstace().sendError("Error2 getAll" + JSON.stringify(err));
        res.json(new Risposta("Error2 getAll", false, null));
      });
  }
);

EventRemote.getInstace().client.on("message", (topic, payload) => {

  try {
    let risposta: Risposta = Risposta.of(JSON.parse(payload.toString()));
    RemoteStatus.getInstace().updateStatus(risposta);
  } catch (err) {
    console.log(err);
    EventRemote.getInstace().sendError(err);
  }

})

app.listen(CONFIG.port, () => {
  EventRemote.getInstace().sendLog("Express server listening on port p1d " + CONFIG.port);
  console.log("Express server listening on port p1d " + CONFIG.port);
});


