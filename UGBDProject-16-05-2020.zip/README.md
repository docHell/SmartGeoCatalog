# UGBD-SmartGeoCatalog

The SmartGeoCatalog (SGC]) project is a free and open source (FOSS) cataloging metadata for spatially referenced resources.
It is a catalog of location-oriented information based on a microservice architecture.

![SchemaImage](https://github.com/docHell/SmartGeoCatalog/blob/master/GeoCatalogQueryUI/src/assets/img/schema.png?raw=true)
