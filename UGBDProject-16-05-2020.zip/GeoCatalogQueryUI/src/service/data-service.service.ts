import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataServiceService {

  //Needed to passa data trough pages

  public dataFromParser: any;
  public dataFromQuery: any;


  constructor() { }




}
