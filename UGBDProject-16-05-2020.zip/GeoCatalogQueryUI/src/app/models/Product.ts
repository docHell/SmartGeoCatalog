 
export class Product {
  _id: String;
  title: String;
  rndt: Object;
  creationdate : Date;

  constructor() {}
}