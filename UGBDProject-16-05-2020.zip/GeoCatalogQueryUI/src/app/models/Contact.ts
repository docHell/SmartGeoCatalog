export class Contact {
    _id: string;
    mail: string;
    organization: string;
  
    constructor() {
    }
    
}