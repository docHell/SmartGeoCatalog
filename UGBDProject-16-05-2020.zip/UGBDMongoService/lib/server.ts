import { DbJobs } from "./../providers/DbJobs";

import app from "./app";
import { Risposta } from '../models/Risposta';
import { MetadataExport } from '../models/Metadatas';
import { connect } from 'mqtt';
import CONFIG from '../config/config.json';
import { Contacts } from "../models/Contacts";

 
const TOPIC = "update_csw";
const CONTACTS_TOPIC = "update_contacts";
const ANSWER_TOPIC  = "answer_topic"


const client = connect(CONFIG.mqtt, { clean: false, clientId: CONFIG.name, keepalive : 50 });
 
client.subscribe(TOPIC)
console.log("CONFIG.mqtt -> " + CONFIG.mqtt)
client.subscribe(CONFIG.STATUS_TOPIC)

client.subscribe(CONTACTS_TOPIC)
 

const PORT = 3705;

app.post(
  "/addMetadata", (req, res, next) => {
    console.log("--- POST METADATA ---");
    console.log("-------------------------------------------------------------------")
    // console.log(req.body);
    console.log("-------------------------------------------------------------------")
    let metadata: MetadataExport = MetadataExport.of(req.body);
    DbJobs.getInstance()
      .addMetadata(metadata)
      .then((risposta: Risposta) => {
        console.log("--------------------------------------");
        console.log(JSON.stringify(risposta));
        console.log("--------------------------------------");
        res.json(risposta);
      });
  }
);

app.post(
  "/addContact", (req, res, next) => {
    console.log("--- add Contact ---");
    console.log("-------------------------------------------------------------------")
    // console.log(req.body);
    console.log("-------------------------------------------------------------------")
    // let metadata : MetadataExport = MetadataExport.of(req.body);
    DbJobs.getInstance()
      .addContacts(req.body)
      .then((risposta: Risposta) => {
        console.log("--------------------------------------");
        console.log(JSON.stringify(risposta));
        console.log("--------------------------------------");
        res.json(risposta);
      }).catch((err) => {

      });
  }
);
app.get("/getAllContacts", (req, res) => {
  DbJobs.getInstance()
    .findAllContact()
    .then((risposta: Risposta) => {
      console.log("--------------------------------------");
      console.log(JSON.stringify(risposta));
      console.log("--------------------------------------");
      res.json(risposta);
    }).catch((err) => {
      res.json(new Risposta("Errore 2 ", false, err));
    })

});

app.get("/countAll", async (req, res) => {

  try {
    let risposta = await DbJobs.getInstance().countAllmetadata();
    console.log("--+++---/countAll---------------------------------");
    console.log(JSON.stringify(risposta));
    console.log("--+++---/countAll---------------------------------");
    res.json(risposta);
  } catch (err) {
    res.json(new Risposta("Errore 3 ", false, err));
  }

});

app.get(
  "/getByID/:metadataId", (req, res, next) => {
    console.log("getProductByID----------------------------");
    console.log("req.params.metadataId ->", req.params.metadataId);
    DbJobs.getInstance()
      .findMetadataByID(req.params.metadataId)
      .then((risposta: Risposta) => {
        res.json(risposta);
      }).catch(() => {
        res.json(new Risposta("Error2 getAll", false, null));
      });
  }
);


function status() {
  let payload = JSON.stringify(new Risposta(CONFIG.name,true,null));
  client.publish(CONFIG.STATUS_TOPIC, payload); 
}


app.get("/test", (req, res) => {
  res.json(new Risposta(CONFIG.name, true, new Date()));
});

 
 

client.on("message", (topic, payload) => {
  
  if (topic === TOPIC) {
    console.log("-------------------------------------------------------------");
    console.log("topic : " +  TOPIC);
    console.log("-------------------------------------------------------------");
    let metadata: MetadataExport = MetadataExport.of(JSON.parse(payload.toString()));
    // console.log("metadata : " + JSON.stringify(metadata));
    DbJobs.getInstance()
      .addMetadata(metadata)
      .then((risposta: Risposta) => {
        console.log("--------------------------------------");
        console.log(JSON.stringify(risposta));
        console.log("--------------------------------------");
       
        client.publish(ANSWER_TOPIC, JSON.stringify(risposta));
      }).catch((err) => {
        let errore: Risposta = new Risposta("Error 2 Insert Document", false, err);
        client.publish(ANSWER_TOPIC, JSON.stringify(errore));
      })
  } 
  if (topic === CONTACTS_TOPIC) {

    console.log("-------------------------------------------------------------");
    console.log("topic : " + CONTACTS_TOPIC);
    console.log("-------------------------------------------------------------");
    let contacts : Contacts = Contacts.of(JSON.parse(payload.toString()));
    DbJobs.getInstance()
    .addContacts(contacts)
    .then((risposta: Risposta) => {
      console.log("--------------------------------------");
      console.log(JSON.stringify(risposta));
      console.log("--------------------------------------");
      client.publish(ANSWER_TOPIC, JSON.stringify(risposta));
    }).catch((err) => {
      let errore: Risposta = new Risposta("Error 3 Insert Document", false, err);
      client.publish(ANSWER_TOPIC, JSON.stringify(errore));
    });
  } 
  // if ( CONFIG.test) {
  //   console.log("-------------------------------------------------------------");
  //   console.log("MQTT Messagge arrived");
  //   console.log("-------------------------------------------------------------");
  //   console.log("topic : " + topic);
  //   console.log("payload : " + payload);
  //   console.log("-------------------------------------------------------------");
  // }
    
 
  
})


setInterval(status, 100000);




app.listen(PORT, () => {
  console.log("-------------------------------------------------------------");
  console.log("Express server listening on port p1d " + PORT);
  console.log("-------------------------------------------------------------");
});


