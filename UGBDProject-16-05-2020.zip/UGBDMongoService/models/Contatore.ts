export class Contatore {
    metadata:  number;
    people:  number;  
    constructor(metadata:  number,people:  number) {
        this.metadata = metadata;
        this.people = people;
    }
  }