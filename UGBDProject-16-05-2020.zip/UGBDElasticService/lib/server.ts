import { EventRemote } from './../../UGBDEdgeServer/providers/EventRemote';
import app from "./app";
import { Risposta } from '../models/Risposta';
import { Product_Db } from '../models/Product';
import { ElasticJobs } from '../providers/ElasticJobs';
import { ElasticExport } from '../models/ElasticExport';
import { connect } from 'mqtt';

import CONFIG from '../config/config.json';
import { ConfigurationError } from "@elastic/elasticsearch/lib/errors";

const PORT = 3710;
// const client = connect(CONFIG.mqtt, { clean: false, clientId: CONFIG.name });
const ELASTIC_TOPIC = "store_elastic";

EventRemote.getInstace().client.subscribe(ELASTIC_TOPIC)
// client.subscribe(ELASTIC_TOPIC);
let counter : number [] = [];


app.post(
  "/addMetadata", (req, res, next) => {
    console.log("-------------------------------------------------------------------")
    console.log("--- POST METADATA ---");
    


    let e: ElasticExport = ElasticExport.of(req.body);
    console.log(JSON.stringify(e));
    console.log("-------------------------------------------------------------------")
    ElasticJobs.getInstance()
      .uploadDocument(e)
      .then((risposta: Risposta) => {
        console.log("--------------------------------------");
        console.log(JSON.stringify(risposta));
        console.log("--------------------------------------");
        res.json(risposta);
      }).catch( (err) => {
        EventRemote.getInstace().sendError("Error /addMetadata "+  err)
        res.json(new Risposta("ErrorUpload : ", false, err));
      })
  }
);

EventRemote.getInstace().client.on("message", (topic, payload) => {

  if (topic === ELASTIC_TOPIC) {

  
    try {
      let e: ElasticExport = ElasticExport.of(JSON.parse(payload.toString()));
   
      ElasticJobs.getInstance()
        .uploadDocument(e)
        .then((risposta: Risposta) => {
          if (risposta.esito) {
           
            console.log("-->ok : " + counter.length);
          } else {
            EventRemote.getInstace().sendError(risposta)
            console.log("-ERROR 1------------------------------"+ counter.length);
            console.log(JSON.stringify(risposta));
            console.log("--------------------------------------");
          }
           
        }).catch((err) => {
          EventRemote.getInstace().sendError("upload documenti 3: " + JSON.stringify(err))
          console.log("-ERROR 2------------------------------"+ counter.length);
          console.log(err);
          console.log("--------------------------------------");
        })
    } catch (err) {
      console.log("-ERROR 3------------------------------"+ counter.length);
      EventRemote.getInstace().sendError("upload documenti 3: " + JSON.stringify(err))
      console.log(err);
      console.log("--------------------------------------");
    }
  }
  counter.push(1)
})


app.get(
  "/checkindex", (req, res, next) => {
    console.log("-------------------------------------------------------------------")
    console.log("--- CHECK INDEX ---");
    console.log("-------------------------------------------------------------------")


    ElasticJobs.getInstance()
      .createIndex()
      .then((risposta: Risposta) => {
        console.log("--------------------------------------");
        console.log(JSON.stringify(risposta));
        console.log("--------------------------------------");
        res.json(risposta);
      }).catch((err) => {
        console.log("--------------------------------------");
        console.log(JSON.stringify(err));
        console.log("--------------------------------------");
        EventRemote.getInstace().sendError("checkindex: " + JSON.stringify(err))
        res.json(new Risposta("ERROR CREATING INDEX", err, null));
      });
  }
);


function status() {
  let payload = JSON.stringify(new Risposta(CONFIG.name, true, null));
  EventRemote.getInstace().client.publish(CONFIG.STATUS_TOPIC, payload);
}

setInterval(status, CONFIG.frequency);

app.get("/test", (req, res) => {
  res.json(new Risposta("ElasticService", true, new Date()));
});

app.listen(PORT, () => {
  console.log("Express server listening on port p1d " + PORT);
});
